<?php

namespace Krakenfm\KrakenfmBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class KrakenfmBundle extends Bundle
{
}
