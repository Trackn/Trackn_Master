<?php

namespace Krakenfm\KrakenfmBundle\Basic;

use Krakenfm\KrakenfmBundle\Entity\CustomTrack;
use Krakenfm\KrakenfmBundle\Entity\Track;
use LastFM\Artist;
use LastFM\Caller\CallerFactory;

class Lastfm
{
    private $_doctrine;
    private $container;

    public function __construct($doctrine, $container)
    {
        $this->_doctrine = $doctrine;
        $this->container = $container;
        CallerFactory::getDefaultCaller()->setApiKey($this->container->getParameter('kraken.lastfm.api_key'));
    }

    public function getCompilesTags($name)
    {
        try {
            $results = array_slice(Artist::getTopTags($name), 0, 10);
            $tags = array();
            if ($results) {
                foreach ($results as $result) {
                    $tags[] = $result->getName();
                }
            }
            $tag_compiles = join(", ", $tags);
        } catch (\Exception $e) {
            $tag_compiles = '';
        }
        return $tag_compiles;
    }

    public function getTopTracks($name)
    {
        return Artist::getTopTracks($name);
    }

    /**
     * Find or create artist for user
     *
     * @param $name
     * @param $tags
     * @param $user
     */
    public function addOrCreateArtist($name, $tags, $user, $is_spotify_artist = false)
    {
        $artist = $this->getDoctrine()->getRepository('KrakenfmBundle:Artist')->findOneBy(
            array('name' => $name, 'user_id' => $user->getId())
        );
        if (!$artist) {
            $artist = new \Krakenfm\KrakenfmBundle\Entity\Artist();
            $artist->setName($name);
            $artist->setUserId($user->getId());
        }
        $artist->setIsSpotifyArtist($is_spotify_artist);
        $artist->setTags($tags);
        $em = $this->getDoctrine()->getManager();
        $em->persist($artist);
        $em->flush();
        return $artist;
    }

    public function getDoctrine()
    {
        return $this->_doctrine;
    }

    /**
     * Find track for the user.
     *
     * @param $artist
     * @param $track
     * @param $user
     */
    public function getTrack($artist, $track, $user)
    {
        $track = $this->getDoctrine()->getRepository('KrakenfmBundle:Track')->findOneBy(
            array('artist' => $artist, 'track' => $track, 'user_id' => $user->getId())
        );
        return $track;
    }

    /**
     * Add track as favourite
     *
     * @param $artist
     * @param $track
     * @param $user
     */
    public function addTrack($artist, $track_name, $user, $is_spotify_song = false, $is_explicit = false, $_album_id = null)
    {
        $tracks = $this->getDoctrine()->getRepository('KrakenfmBundle:Track')->findBy(
            array('artist' => $artist, 'user_id' => $user->getId())
        );

        if (count($tracks) >= 3) { //max available tracks faviourited
            return false;
        }

        $api = new SpotifyWebApiExtended();

        try {
            $track_info = \LastFM\Track::getInfo($artist, $track_name);
        } catch (\Exception $e) {
            $track_info = null;
        }

        $album_info = null;
        $album_spotify_info = null;
        if ($track_info) {
            if ($track_info->getAlbum()) {
                if ($_album_id) {
                    $album_spotify_info = $api->getAlbum($_album_id);
                } else {
                    try {
                        $album_info = \LastFM\Album::getInfo($artist, $track_info->getAlbum());
                        $search_string = 'album:"' . $track_info->getAlbum() . '" artist:"' . $artist . '"';
                        $albums = $api->search($search_string, 'album');
                        $album_id = 0;
                        foreach ($albums->albums->items as $album) {
                            if (strtolower($album->name) == strtolower($album_info->getName())) {
                                $album_id = $album->id;
                            }
                        }
                        if (!$album_id) {
                            foreach ($albums->albums->items as $album) {
                                if (strpos($album->name, $track_info->getAlbum()) !== false && !$album_id) {
                                    $album_id = $album->id;
                                }
                            }
                        }
                        if ($album_id) {
                            $album_spotify_info = $api->getAlbum($album_id);
                        }
                    } catch (\Exception $e) {
                    }
                }
            }
        }

        $custom_track = $this->getCustomTrack($artist, $track_name, $user);

        $track = new Track();
        $track->setArtist($artist);
        $track->setTrack($track_name);
        $track->setUserId($user->getId());
        if ($track_info) {
            $track->setAlbum($track_info->getAlbum());
        } else {
            $track->setAlbum('');
        }
        if ($album_spotify_info) {
            $track->setYear($album_spotify_info->release_date);
        }
        $track->setIsSpotifySong($is_spotify_song);
        $track->setIsExplicit($is_explicit);
        if ($custom_track) {
            $track->setIsTop10(false);
        } else {
            $track->setIsTop10(true);
        }
        $em = $this->getDoctrine()->getManager();
        $em->persist($track);
        $em->flush();
        return true;
    }

    /**
     * Find all tracks for the user and artist.
     *
     * @param $artist
     * @param $track
     * @param $user
     */
    public function getTracksForArtist($artist, $user)
    {
        $tracks = $this->getDoctrine()->getRepository('KrakenfmBundle:Track')->findBy(
            array('user_id' => $user->getId(), 'artist' => $artist)
        );
        return $tracks;
    }

    public function getCustomTrack($artist, $track, $user)
    {
        $track_obj = $this->getDoctrine()->getRepository('KrakenfmBundle:CustomTrack')->findOneBy(
            array('artist' => $artist, 'track' => $track, 'user_id' => $user->getId())
        );
        return $track_obj;
    }

    /**
     * Create or edit custom track
     *
     * @param $artist_name
     * @param $track_name
     * @param $order
     * @param $user
     */
    public function createOrEditCustomTrack($artist, $track, $order, $user)
    {
        $track_obj = $this->getDoctrine()->getRepository('KrakenfmBundle:CustomTrack')->findOneBy(
            array('artist' => $artist, 'user_id' => $user->getId(), 'order_id' => $order)
        );
        if (!$track_obj) {
            $track_obj = new CustomTrack();
            $track_obj->setArtist($artist);
            $track_obj->setUserId($user->getId());
            $track_obj->setOrderId($order);
        }
        $track_obj->setTrack($track);
        $em = $this->getDoctrine()->getManager();
        $em->persist($track_obj);
        $em->flush();
    }
}