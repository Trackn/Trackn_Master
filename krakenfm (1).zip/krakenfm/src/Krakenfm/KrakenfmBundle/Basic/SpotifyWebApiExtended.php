<?php

namespace Krakenfm\KrakenfmBundle\Basic;

use SpotifyWebAPI\Request;
use SpotifyWebAPI\SpotifyWebAPI;

class SpotifyWebApiExtended extends SpotifyWebAPI
{
    public function getMyFollowedArtists($options = array())
    {
        $defaults = array(
            'offset' => 0,
            'type' => 'artist',
        );

        $options = $this->mergeOptions($defaults, $options, true);
        $headers = $this->authHeaders();

        $request = new Request();

        $uri = '/v1/me/following';

        $response = $request->api('GET', $uri, $options, $headers);

        return $response['body'];
    }
}