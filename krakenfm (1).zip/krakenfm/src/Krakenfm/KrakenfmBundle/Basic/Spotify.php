<?php

namespace Krakenfm\KrakenfmBundle\Basic;

class Spotify
{
    /**
     * @var string
     */
    private $_access_token;

    /**
     * @var \SpotifyWebAPI\SpotifyWebAPI
     */
    private $_api;

    public function __construct($access_token)
    {
        $this->_access_token = $access_token;

        $this->_api = new SpotifyWebApiExtended();
        $this->_api->setAccessToken($access_token);
    }

    public function getTracksByIds($ids)
    {
        $result = array();
        $tracks = $this->_api->getTracks($ids);
        foreach ($tracks->tracks as $track) {
            $result[] = array(
                'name' => $track->name,
                'explicit' => $track->explicit,
				'album_id' => $track->album->id,
            );
        }
        return $result;
    }

    public function getFollowedArtists()
    {
        $limit = 50;
        $after = '';
        $artists = array();

        while ($after !== null) {
            if ($after) {
                $followed_artists = $this->_api->getMyFollowedArtists(array('limit' => $limit, 'after' => $after));
            } else {
                $followed_artists = $this->_api->getMyFollowedArtists(array('limit' => $limit));
            }
            $artists = array_merge($artists, $followed_artists->artists->items);
            $after = $followed_artists->artists->cursors->after;
        }

        $result = array();
        foreach ($artists as $artist) {
            $result[$artist->id] = $artist->name;
        }

        return $result;
    }

    public function getAllTracks()
    {
        $playlist_tracks = $this->_getAllPlaylistTracks();
        $saved_tracks = $this->_getAllSavedTracks();
        $tracks = array_merge($playlist_tracks, $saved_tracks);
        $tracks = $this->_prepareTracks($tracks);
        $tracks = $this->_sortTracks($tracks);
        return $tracks;
    }

    public function getTracks()
    {
        $tracks = $this->_getAllSavedTracks();
        $tracks = $this->_prepareTracks($tracks);
        $tracks = $this->_sortTracks($tracks);
        return $tracks;
    }

    private function _getAllSavedTracks()
    {
        $offset = 0;
        $limit = 50;
        $total = 10000;
        $tracks = array();

        //get raw data
        while ($offset < $total) {
            $saved_tracks = $this->_api->getMySavedTracks(array('offset' => $offset, 'limit' => $limit));
            $tracks = array_merge($tracks, $saved_tracks->items);
            $total = $saved_tracks->total;
            $offset += $limit;
        }

        return $tracks;
    }

    private function _prepareTracks($tracks)
    {
        $result = array();
        foreach ($tracks as $track) {
            $artist_id = $track->track->artists[0]->id;
            $artist_name = $track->track->artists[0]->name;
            $track_id = $track->track->id;
            $track_name = $track->track->name;
            $track_popularity = $track->track->popularity;
            if (!array_key_exists($artist_id, $result)) {
                $result[$artist_id] = array();
                $result[$artist_id]['name'] = $artist_name;
                $result[$artist_id]['tracks'] = array();
            }
            $result[$artist_id]['tracks'][$track_id] = array(
                'name' => $track_name,
                'popularity' => $track_popularity
            );
        }
        return $result;
    }

    private function _sortTracks($tracks)
    {
        $result = array();
        foreach ($tracks as $artist_id => $artist_info) {
            $artist_tracks = $artist_info['tracks'];

            $popularity = array();
            foreach ($artist_tracks as $key => $track) {
                $popularity[$key] = $track['popularity'];
            }
            arsort($popularity);
            $popularity = array_slice($popularity, 0, 3);

            $reduced_tracks = array();
            foreach ($popularity as $_key => $_sort) {
                $reduced_tracks[$_key] = $artist_tracks[$_key];
            }
            $result[$artist_id] = $artist_info;
            $result[$artist_id]['tracks'] = $reduced_tracks;
        }
        return $result;
    }

    private function _getAllPlaylistTracks()
    {
        $user_info = $this->_api->me();
        $user_id = $user_info->id;

        $tracks = array();

        $playlists = $this->_getAllPlayLists($user_id);
        $playlist_ids = array();
        foreach ($playlists as $playlist) {
            $playlist_ids[] = $playlist->id;
        }

        foreach ($playlist_ids as $playlist_id) {
            try {
                $tracks = array_merge($tracks, $this->_getTracksForPlaylist($user_id, $playlist_id));
            } catch (\Exception $e) {
            }
        }
        return $tracks;
    }

    private function _getAllPlayLists($user_id)
    {
        $offset = 0;
        $limit = 50;
        $total = 10000;
        $playlists = array();

        //get raw data
        while ($offset < $total) {
            $_new_playlists = $this->_api->getUserPlaylists($user_id, array('offset' => $offset, 'limit' => $limit));
            $playlists = array_merge($playlists, $_new_playlists->items);
            $total = $_new_playlists->total;
            $offset += $limit;
        }

        return $playlists;
    }

    private function _getTracksForPlaylist($user_id, $playlist_id)
    {
        $offset = 0;
        $limit = 50;
        $total = 10000;
        $tracks = array();

        //get raw data
        while ($offset < $total) {
            try {
                $saved_tracks = $this->_api->getUserPlaylistTracks($user_id, $playlist_id, array('offset' => $offset, 'limit' => $limit));
                $tracks = array_merge($tracks, $saved_tracks->items);
                $total = $saved_tracks->total;
                $offset += $limit;
            } catch (\Exception $e) {
                $total = 0;
                $offset = 0;
            }
        }

        return $tracks;
    }
}