<?php
namespace Krakenfm\KrakenfmBundle\Command;

use Krakenfm\KrakenfmBundle\Basic\Lastfm;
use Krakenfm\KrakenfmBundle\Basic\Spotify;
use Krakenfm\KrakenfmBundle\Entity\SpotifyParser;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class SpotifyParserArtistCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('krakenfm:spotify_parser_artist')
            ->setDescription('Run spotify parser for particular user')
            ->addArgument(
                'user_id',
                InputArgument::REQUIRED,
                'User id'
            )
            ->addArgument(
                'artist',
                InputArgument::REQUIRED,
                'Artist name'
            )
            ->addArgument(
                'track_1',
                InputArgument::OPTIONAL,
                'Track ID 1'
            )
            ->addArgument(
                'track_2',
                InputArgument::OPTIONAL,
                'Track ID 2'
            )
            ->addArgument(
                'track_3',
                InputArgument::OPTIONAL,
                'Track ID 3'
            )
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        try {
            $doctrine = $this->getContainer()->get('doctrine');
            $em = $doctrine->getManager();

            $user_id = $input->getArgument('user_id');
            $user = $doctrine->getRepository('KrakenfmBundle:User')->find($user_id);

            $access_token = $user->getSpotifyAccessToken();
            if (!$access_token) {
                $output->writeln('No access token.');
                die();
            }

            $artist_name = $input->getArgument('artist');
            $spotify_track_ids = array();
            if ($input->getArgument('track_1')) {
                $spotify_track_ids[] = $input->getArgument('track_1');
            }
            if ($input->getArgument('track_2')) {
                $spotify_track_ids[] = $input->getArgument('track_2');
            }
            if ($input->getArgument('track_3')) {
                $spotify_track_ids[] = $input->getArgument('track_3');
            }

            $_lastfm = new Lastfm($this->getContainer()->get('doctrine'), $this->getContainer());

            $tag_compiles = $_lastfm->getCompilesTags($artist_name);

            $_lastfm->addOrCreateArtist($artist_name, $tag_compiles, $user, true);

            if (!count($spotify_track_ids)) {
                die();
            }

            $spotify = new Spotify($access_token);
            $spotify_tracks = $spotify->getTracksByIds($spotify_track_ids);

            $_remove_tracks = $_lastfm->getTracksForArtist($artist_name, $user);
            $this->_removeTracks($_remove_tracks);

            $artist_tracks = $_lastfm->getTopTracks($artist_name);
            $order = 0;
            foreach ($spotify_tracks as $spotify_track) {
                $_found = false;
                $spotify_track_name = $spotify_track['name'];
                $spotify_track_explicit = $spotify_track['explicit'];
				$spotify_album_id = $spotify_track['album_id'];
                foreach ($artist_tracks as $artist_track) {
                    if ($artist_track->getName() == $spotify_track_name) {
                        $_lastfm->addTrack($artist_name, $spotify_track_name, $user, true, $spotify_track_explicit, $spotify_album_id);
                        $_found = true;
                    }
                }
                if (!$_found) {
                    $_lastfm->createOrEditCustomTrack($artist_name, $spotify_track_name, $order, $user);
                    $_lastfm->addTrack($artist_name, $spotify_track_name, $user, true, $spotify_track_explicit);
                    $order++;
                }
            }
        } catch (\Exception $e) {
            print $e->getMessage();
            print $e->getTraceAsString();
        }
    }

    private function _removeTracks($_remove_tracks)
    {
        foreach ($_remove_tracks as $_remove_track) {
            $em = $this->getContainer()->get('doctrine')->getManager();
            $em->remove($_remove_track);
            $em->flush();
        }
    }
}