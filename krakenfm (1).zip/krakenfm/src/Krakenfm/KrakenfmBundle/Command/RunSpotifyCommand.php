<?php
namespace Krakenfm\KrakenfmBundle\Command;

use Krakenfm\KrakenfmBundle\Basic\Lastfm;
use Krakenfm\KrakenfmBundle\Basic\Spotify;
use Krakenfm\KrakenfmBundle\Entity\SpotifyParser;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class RunSpotifyCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('krakenfm:run_spotify')
            ->setDescription('Run spotify');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $doctrine = $this->getContainer()->get('doctrine');
        $em = $doctrine->getManager();

        $users = $doctrine->getRepository('KrakenfmBundle:User')->findAll();
        foreach ($users as $user) {
            if ($user->getRunSpotify()) {
                $user->setRunSpotify(false);
                $em->persist($user);
                $em->flush();

                $path = $this->getContainer()->get('kernel')->getRootDir();
                $command = "php ".$path."/console krakenfm:spotify_parser ".$user->getId()." > /dev/null 2>/dev/null &";
                exec($command);
            }
        }
    }
}