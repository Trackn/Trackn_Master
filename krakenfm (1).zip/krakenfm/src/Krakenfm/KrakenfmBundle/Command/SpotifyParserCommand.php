<?php
namespace Krakenfm\KrakenfmBundle\Command;

use Krakenfm\KrakenfmBundle\Basic\Lastfm;
use Krakenfm\KrakenfmBundle\Basic\Spotify;
use Krakenfm\KrakenfmBundle\Entity\SpotifyParser;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class SpotifyParserCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('krakenfm:spotify_parser')
            ->setDescription('Run spotify parser for particular user')
            ->addArgument(
                'user_id',
                InputArgument::REQUIRED,
                'User id'
            );
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $start = microtime(TRUE);
        $doctrine = $this->getContainer()->get('doctrine');
        $em = $doctrine->getManager();

        $user_id = $input->getArgument('user_id');
        $user = $doctrine->getRepository('KrakenfmBundle:User')->find($user_id);
        $previous_spotify_parser = $doctrine->getRepository('KrakenfmBundle:SpotifyParser')
            ->findOneBy(array(
                'user' => $user,
                'isRunning' => 1,
            ));

        if ($previous_spotify_parser) {
            $output->writeln('Task is already running.');die();
        }

        $access_token = $user->getSpotifyAccessToken();
        if (!$access_token) {
            $output->writeln('No access token.');die();
        }

        $spotify_parser = new SpotifyParser();
        $spotify_parser->setUser($user);
        $spotify_parser->setIsRunning(true);
        $spotify_parser->setIsFinished(false);
        $em->persist($spotify_parser);
        $em->flush();

        try {
            $this->_parseFollowedArtists($user);
            $this->_parseTracks($user);
        } catch (\Exception $e) {
            print $e->getMessage();
            print $e->getTraceAsString();
        }
        $spotify_parser->setIsFinished(true);
        $spotify_parser->setIsRunning(false);
        $em->persist($spotify_parser);
        $em->flush();


        $finish = microtime(true);
        $totaltime = $finish - $start;

        $output->writeln("This script took ".$totaltime." seconds to run");
    }

    private function _parseFollowedArtists($user)
    {
        $access_token = $user->getSpotifyAccessToken();

        $_lastfm = new Lastfm($this->getContainer()->get('doctrine'), $this->getContainer());

        $spotify = new Spotify($access_token);
        $artists = $spotify->getFollowedArtists();

        $_i = 1;
        $path = $this->getContainer()->get('kernel')->getRootDir();

        foreach ($artists as $artist_id => $artist_name) {
            $command = 'php '.$path.'/console krakenfm:spotify_parser_artist '.$user->getId().' "'.addslashes($artist_name).'" > /dev/null 2>/dev/null &';
			//$command = 'php '.$path.'/console krakenfm:spotify_parser_artist '.$user->getId().' "'.$artist_name.'"';
            print $command."\n";
            exec($command);

            if ($_i % 5 == 0) {
                sleep(1);
            }

            $_i++;

            /*
            $tag_compiles = $_lastfm->getCompilesTags($artist_name);
            $_lastfm->addOrCreateArtist($artist_name, $tag_compiles, $user);
            */
        }
    }

    private function _parseTracks($user)
    {
        $access_token = $user->getSpotifyAccessToken();

        $spotify = new Spotify($access_token);
        $tracks = $spotify->getAllTracks();

        //save artists
        $_lastfm = new Lastfm($this->getContainer()->get('doctrine'), $this->getContainer());
        $_i = 1;
        $path = $this->getContainer()->get('kernel')->getRootDir();
        $_count = 0;
        foreach ($tracks as $spotify_artist_id => $spotify_artist_info) {
            $artist_name = $spotify_artist_info['name'];
            $spotify_tracks = $spotify_artist_info['tracks'];

            $track_ids = array();
            foreach ($spotify_tracks as $spotify_track_id => $spotify_track) {
                $track_ids[] = $spotify_track_id;
            }

            $tracks_ids_list = join('" "', $track_ids);

            $_count += count($tracks_ids_list);

            $command = 'php '.$path.'/console krakenfm:spotify_parser_artist '.$user->getId().' "'.addslashes($artist_name).'" "'.$tracks_ids_list.'" > /dev/null 2>/dev/null &';
            //$command = 'php '.$path.'/console krakenfm:spotify_parser_artist '.$user->getId().' "'.$artist_name.'" "'.$tracks_ids_list.'"';
            print $command."\n";
            $result = exec($command);
            /*
            if ($result != '') {
                print $command."\n";
                print_r($result);
                print "\n";
            }
            */

            if ($_i % 5 == 0) {
                sleep(1);
            }

            $_i++;

            /*
            $tag_compiles = $_lastfm->getCompilesTags($artist_name);

            $_lastfm->addOrCreateArtist($artist_name, $tag_compiles, $user);

            $_remove_tracks = $_lastfm->getTracksForArtist($artist_name, $user);
            $this->_removeTracks($_remove_tracks);

            $artist_tracks = $_lastfm->getTopTracks($artist_name);
            $order = 0;
            foreach ($spotify_tracks as $spotify_track) {
                $_found = false;
                $_i++;
                foreach ($artist_tracks as $artist_track) {
                    if ($artist_track->getName() == $spotify_track) {
                        $_lastfm->addTrack($artist_name, $spotify_track, $user);
                        $_found = true;
                    }
                }
                if (!$_found) {
                    $_lastfm->createOrEditCustomTrack($artist_name, $spotify_track, $order, $user);
                    $_lastfm->addTrack($artist_name, $spotify_track, $user);
                    $order++;
                }
            }
            */
        }
        print $_count;
    }

    private function _removeTracks($_remove_tracks)
    {
        foreach ($_remove_tracks as $_remove_track) {
            $em = $this->getContainer()->get('doctrine')->getManager();
            $em->remove($_remove_track);
            $em->flush();
        }
    }
}