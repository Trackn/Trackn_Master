<?php
namespace Krakenfm\KrakenfmBundle\Command;

use Krakenfm\KrakenfmBundle\Basic\Lastfm;
use Krakenfm\KrakenfmBundle\Basic\Spotify;
use Krakenfm\KrakenfmBundle\Basic\SpotifyWebApiExtended;
use Krakenfm\KrakenfmBundle\Entity\SpotifyParser;
use LastFM\Caller\CallerFactory;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class UpdateTrackInfoCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('krakenfm:update_track_info')
            ->setDescription('Update track info');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        try {
            CallerFactory::getDefaultCaller()->setApiKey($this->getContainer()->getParameter('kraken.lastfm.api_key'));

            $doctrine = $this->getContainer()->get('doctrine');
            $em = $doctrine->getManager();

            $tracks = $doctrine->getRepository('KrakenfmBundle:Track')->findAll();

            $api = new SpotifyWebApiExtended();
            $spotify_api = new SpotifyWebApiExtended();

            $lastfm = new Lastfm($doctrine, $this->getContainer());

            foreach ($tracks as $track) {
                $artist = $track->getArtist();
                $track_name = $track->getTrack();

                $album_id = null;
                try {
                    $track_info = \LastFM\Track::getInfo($artist, $track_name);
                } catch (\Exception $e) {
                    continue;
                }
                print $track->getId()." - ".$track->getTrack()." - ".$track_info->getAlbum()."\n";

                if ($track_info->getAlbum()) {
                    try {
                        $album_info = \LastFM\Album::getInfo($artist, $track_info->getAlbum());
                        $search_string = 'album:"' . $album_info->getName() . '" artist:"' . $artist . '"';
                        $albums = $api->search($search_string, 'album');
                        $album_id = false;
                        foreach ($albums->albums->items as $album) {
                            if ($album->name == $album_info->getName()) {
                                $album_id = $album->id;
                            }
                        }
                        if (!$album_id) {
                            foreach ($albums->albums->items as $album) {
                                if (strpos($album->name, $album_info->getName()) !== false && !$album_id) {
                                    $album_id = $album->id;
                                }
                            }
                        }
                    } catch (\Exception $e) {
                    }
                } else {
                    $album_info = null;
                }

                if ($album_id) {
                    $album_spotify_info = $api->getAlbum($album_id);
                } else {
                    $album_spotify_info = null;
                }

                $user = $doctrine->getRepository('KrakenfmBundle:User')->find($track->getUserId());

                $custom_track = $lastfm->getCustomTrack($artist, $track_name, $user);

                $search_string = 'track:"' . $track_name . '" artist:"' . $artist . '"';
                $find_track = $spotify_api->search($search_string, 'track');
                $is_explicit = false;
                foreach ($find_track->tracks->items as $item) {
                    if ($item->name == $track_name) {
                        $is_explicit = $item->explicit;
                    }
                }

                if ($album_info) {
                    $track->setAlbum($album_info->getName());
                }
                $track->setIsExplicit($is_explicit);
                if ($album_spotify_info) {
                    $track->setYear($album_spotify_info->release_date);
                }
                if ($custom_track) {
                    $track->setIsTop10(false);
                } else {
                    $track->setIsTop10(true);
                }
                $em->persist($track);
                $em->flush();
            }
        } catch (\Exception $e) {
            print $e->getMessage();
            print $e->getTraceAsString();
        }
    }
}