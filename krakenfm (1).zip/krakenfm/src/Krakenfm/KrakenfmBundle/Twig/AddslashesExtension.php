<?php
namespace Krakenfm\KrakenfmBundle\Twig;

class AddslashesExtension extends \Twig_Extension
{
    public function getFilters()
    {
        return array(
            new \Twig_SimpleFilter('addslashes', 'addslashes'),
        );
    }

    public function getName()
    {
        return 'addslashes';
    }
}