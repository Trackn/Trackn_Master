<?php

namespace Krakenfm\KrakenfmBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Artist
 *
 * @ORM\Table()
 * @ORM\Entity
 */
class Artist
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="tags", type="text")
     */
    private $tags;

    /**
     * @var integer
     *
     * @ORM\Column(name="user_id", type="integer", length=255)
     */
    private $user_id;

    /**
     * @var string
     *
     * @ORM\Column(name="is_spotify_artist", type="boolean")
     */
    private $is_spotify_artist = false;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Artist
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set tags
     *
     * @param string $tags
     * @return Artist
     */
    public function setTags($tags)
    {
        $this->tags = $tags;

        return $this;
    }

    /**
     * Get tags
     *
     * @return string 
     */
    public function getTags()
    {
        return $this->tags;
    }

    /**
     * Set user_id
     *
     * @param integer $userId
     * @return Artist
     */
    public function setUserId($userId)
    {
        $this->user_id = $userId;

        return $this;
    }

    /**
     * Get user_id
     *
     * @return integer 
     */
    public function getUserId()
    {
        return $this->user_id;
    }

    /**
     * Set is_spotify_artist
     *
     * @param boolean $isSpotifyArtist
     * @return Artist
     */
    public function setIsSpotifyArtist($isSpotifyArtist)
    {
        $this->is_spotify_artist = $isSpotifyArtist;

        return $this;
    }

    /**
     * Get is_spotify_artist
     *
     * @return boolean 
     */
    public function getIsSpotifyArtist()
    {
        return $this->is_spotify_artist;
    }
}
