<?php

namespace Krakenfm\KrakenfmBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Track
 *
 * @ORM\Table()
 * @ORM\Entity
 */
class Track
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="artist", type="string", length=255)
     */
    private $artist;

    /**
     * @var string
     *
     * @ORM\Column(name="track", type="string", length=255)
     */
    private $track;

    /**
     * @var string
     *
     * @ORM\Column(name="album", type="string", length=255, nullable=true)
     */
    private $album;

    /**
     * @var string
     *
     * @ORM\Column(name="year", type="string", length=255, nullable=true)
     */
    private $year;

    /**
     * @var string
     *
     * @ORM\Column(name="is_top_10", type="boolean")
     */
    private $is_top_10 = false;

    /**
     * @var string
     *
     * @ORM\Column(name="is_spotify_song", type="boolean")
     */
    private $is_spotify_song = false;

    /**
     * @var string
     *
     * @ORM\Column(name="is_spotify_artist", type="boolean")
     */
    private $is_spotify_artist = false;

    /**
     * @var string
     *
     * @ORM\Column(name="is_explicit", type="boolean")
     */
    private $is_explicit = false;

    /**
     * @var integer
     *
     * @ORM\Column(name="user_id", type="integer")
     */
    private $user_id;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set artist
     *
     * @param string $artist
     * @return Track
     */
    public function setArtist($artist)
    {
        $this->artist = $artist;

        return $this;
    }

    /**
     * Get artist
     *
     * @return string 
     */
    public function getArtist()
    {
        return $this->artist;
    }

    /**
     * Set track
     *
     * @param string $track
     * @return Track
     */
    public function setTrack($track)
    {
        $this->track = $track;

        return $this;
    }

    /**
     * Get track
     *
     * @return string 
     */
    public function getTrack()
    {
        return $this->track;
    }

    /**
     * Set userId
     *
     * @param integer $userId
     * @return Track
     */
    public function setUserId($user_id)
    {
        $this->user_id = $user_id;

        return $this;
    }

    /**
     * Get userId
     *
     * @return integer 
     */
    public function getUserId()
    {
        return $this->user_id;
    }

    /**
     * Set album
     *
     * @param string $album
     * @return Track
     */
    public function setAlbum($album)
    {
        $this->album = $album;

        return $this;
    }

    /**
     * Get album
     *
     * @return string 
     */
    public function getAlbum()
    {
        return $this->album;
    }

    /**
     * Set year
     *
     * @param string $year
     * @return Track
     */
    public function setYear($year)
    {
        $this->year = $year;

        return $this;
    }

    /**
     * Get year
     *
     * @return string 
     */
    public function getYear()
    {
        return $this->year;
    }

    /**
     * Set is_top_10
     *
     * @param boolean $isTop10
     * @return Track
     */
    public function setIsTop10($isTop10)
    {
        $this->is_top_10 = $isTop10;

        return $this;
    }

    /**
     * Get is_top_10
     *
     * @return boolean 
     */
    public function getIsTop10()
    {
        return $this->is_top_10;
    }

    /**
     * Set is_spotify_song
     *
     * @param boolean $isSpotifySong
     * @return Track
     */
    public function setIsSpotifySong($isSpotifySong)
    {
        $this->is_spotify_song = $isSpotifySong;

        return $this;
    }

    /**
     * Get is_spotify_song
     *
     * @return boolean 
     */
    public function getIsSpotifySong()
    {
        return $this->is_spotify_song;
    }

    /**
     * Set is_explicit
     *
     * @param boolean $isExplicit
     * @return Track
     */
    public function setIsExplicit($isExplicit)
    {
        $this->is_explicit = $isExplicit;

        return $this;
    }

    /**
     * Get is_explicit
     *
     * @return boolean 
     */
    public function getIsExplicit()
    {
        return $this->is_explicit;
    }

    /**
     * Set is_spotify_artist
     *
     * @param boolean $isSpotifyArtist
     * @return Track
     */
    public function setIsSpotifyArtist($isSpotifyArtist)
    {
        $this->is_spotify_artist = $isSpotifyArtist;

        return $this;
    }

    /**
     * Get is_spotify_artist
     *
     * @return boolean 
     */
    public function getIsSpotifyArtist()
    {
        return $this->is_spotify_artist;
    }
}
