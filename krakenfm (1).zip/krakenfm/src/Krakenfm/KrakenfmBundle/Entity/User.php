<?php

namespace Krakenfm\KrakenfmBundle\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;

/**
 * User
 *
 * @ORM\Table()
 * @ORM\Entity
 */
class User
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="email", type="string", length=255)
     */
    private $email;

    /**
     * @var string
     *
     * @ORM\Column(name="spotify_access_token", type="string", length=255)
     */
    private $spotify_access_token = '';

    /**
     * @var boolean
     *
     * @ORM\Column(name="run_spotify", type="boolean")
     */
    private $run_spotify = false;

    /**
     * @ORM\OneToMany(targetEntity="SpotifyParser", mappedBy="user")
     */
    protected $spotify_parsers;

    public function __construct()
    {
        $this->spotify_parsers = new ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set email
     *
     * @param string $email
     * @return User
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string 
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set spotify_access_token
     *
     * @param string $spotifyAccessToken
     * @return User
     */
    public function setSpotifyAccessToken($spotifyAccessToken)
    {
        $this->spotify_access_token = $spotifyAccessToken;

        return $this;
    }

    /**
     * Get spotify_access_token
     *
     * @return string 
     */
    public function getSpotifyAccessToken()
    {
        return $this->spotify_access_token;
    }

    /**
     * Add spotify_parsers
     *
     * @param \Krakenfm\KrakenfmBundle\Entity\SpotifyParser $spotifyParsers
     * @return User
     */
    public function addSpotifyParser(\Krakenfm\KrakenfmBundle\Entity\SpotifyParser $spotifyParsers)
    {
        $this->spotify_parsers[] = $spotifyParsers;

        return $this;
    }

    /**
     * Remove spotify_parsers
     *
     * @param \Krakenfm\KrakenfmBundle\Entity\SpotifyParser $spotifyParsers
     */
    public function removeSpotifyParser(\Krakenfm\KrakenfmBundle\Entity\SpotifyParser $spotifyParsers)
    {
        $this->spotify_parsers->removeElement($spotifyParsers);
    }

    /**
     * Get spotify_parsers
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getSpotifyParsers()
    {
        return $this->spotify_parsers;
    }

    /**
     * Set run_spotify
     *
     * @param boolean $runSpotify
     * @return User
     */
    public function setRunSpotify($runSpotify)
    {
        $this->run_spotify = $runSpotify;

        return $this;
    }

    /**
     * Get run_spotify
     *
     * @return boolean 
     */
    public function getRunSpotify()
    {
        return $this->run_spotify;
    }
}
