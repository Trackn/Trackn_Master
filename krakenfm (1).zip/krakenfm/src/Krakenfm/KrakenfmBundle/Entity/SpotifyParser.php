<?php

namespace Krakenfm\KrakenfmBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * SpotifyParser
 *
 * @ORM\Table()
 * @ORM\Entity
 */
class SpotifyParser
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_running", type="boolean")
     */
    private $isRunning;

    /**
     * @var boolean
     *
     * @ORM\Column(name="is_finished", type="boolean")
     */
    private $isFinished;

    /**
     * @ORM\ManyToOne(targetEntity="User", inversedBy="spotify_parsers")
     * @Assert\NotBlank()
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id")
     */
    protected $user;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set isRunning
     *
     * @param boolean $isRunning
     * @return SpotifyParser
     */
    public function setIsRunning($isRunning)
    {
        $this->isRunning = $isRunning;

        return $this;
    }

    /**
     * Get isRunning
     *
     * @return boolean 
     */
    public function getIsRunning()
    {
        return $this->isRunning;
    }

    /**
     * Set isFinished
     *
     * @param boolean $isFinished
     * @return SpotifyParser
     */
    public function setIsFinished($isFinished)
    {
        $this->isFinished = $isFinished;

        return $this;
    }

    /**
     * Get isFinished
     *
     * @return boolean 
     */
    public function getIsFinished()
    {
        return $this->isFinished;
    }

    /**
     * Set user
     *
     * @param \Krakenfm\KrakenfmBundle\Entity\User $user
     * @return SpotifyParser
     */
    public function setUser(\Krakenfm\KrakenfmBundle\Entity\User $user = null)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return \Krakenfm\KrakenfmBundle\Entity\User 
     */
    public function getUser()
    {
        return $this->user;
    }
}
