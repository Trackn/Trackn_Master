<?php

namespace Krakenfm\KrakenfmBundle\Controller;

use Krakenfm\KrakenfmBundle\Basic\Lastfm;
use Krakenfm\KrakenfmBundle\Basic\SpotifyWebApiExtended;
use Krakenfm\KrakenfmBundle\Entity\CustomTrack;
use Krakenfm\KrakenfmBundle\Entity\Track;
use Krakenfm\KrakenfmBundle\Entity\User;
use LastFM\Artist;
use LastFM\Caller\CallerFactory;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Cookie;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\Security\Http\Session\SessionAuthenticationStrategy;

class DefaultController extends Controller
{
    /**
     * Login action
     *
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function loginAction(Request $request)
    {
        $cookies = $request->cookies;

        $user_email = '';
        if ($cookies->has('user_email')) {
            $user_email = $cookies->get('user_email');
        }

        //creat login form
        $form = $this->createFormBuilder()
            ->add('email', 'email', array('data' => $user_email))
            ->add('enter', 'submit', array('label' => 'Enter'))
            ->getForm();

        //check form
        $form->handleRequest($request);

        /**
         * If form is valid: create new user if none,
         * save user to the session and redirect to the dashboard
         */
        if ($form->isValid()) {
            $this->__checkUser($form['email']->getData());

            $time = time() + (3600 * 24 * 7);
            $response = new Response();
            $response->headers->setCookie(new Cookie("user_email", $form['email']->getData(), $time));
            $response->send();

            return $this->redirect($this->generateUrl('krakenfm_dashboard'));
        }

        return $this->render('KrakenfmBundle:Default:login.html.twig', array(
            'form' => $form->createView(),
        ));
    }

    /**
     * Dashboard
     */
    public function dashboardAction(Request $request)
    {
        //check user
        $user = $this->__getUser();
        if (!$user) { //no user authenticated? redirect to the login page
            return $this->redirect($this->generateUrl('krakenfm_login'));
        }

        $artists = $this->__getArtists($user);
        $tracks = $this->__getTracks($user);
        $artists_count = count($artists);
        $tracks_count = count($tracks);

        //spotify
        $spotify_params = array();
        $spotify_params['client_id'] = $this->container->getParameter('kraken.spotify.client_id');
        $spotify_params['client_secrete'] = $this->container->getParameter('kraken.spotify.client_secret');
        $spotify_params['scopes'] = $this->container->getParameter('kraken.spotify.scopes');
        $spotify_params['redirect_uri'] = $this->generateUrl('spotify_auth', array(), UrlGeneratorInterface::ABSOLUTE_URL);
        $spotify_session = new \SpotifyWebAPI\Session($spotify_params['client_id'],
                                                      $spotify_params['client_secrete'],
                                                      $spotify_params['redirect_uri']);

        $spotify_authorize_url = $spotify_session->getAuthorizeUrl(array(
            'scope' => $spotify_params['scopes']
        ));

        $spotify = $request->query->getInt('spotify', 0);

        $spotify_parser_in_q = false;
        if ($spotify) {
            $spotify_parser_in_q = true;
        } else {
            $previous_spotify_parser = $this->getDoctrine()->getRepository('KrakenfmBundle:SpotifyParser')
                ->findOneBy(array(
                    'user' => $user,
                    'isRunning' => 1,
                ));
            if ($user->getRunSpotify() || $previous_spotify_parser) {
                $spotify_parser_in_q = true;
            }
        }

        return $this->render('KrakenfmBundle:Default:dashboard.html.twig', array(
            'user' => $user,
            'artists' => $artists,
            'artists_count' => $artists_count,
            'tracks_count' => $tracks_count,
            'spotify_params' => $spotify_params,
            'spotify_session' => $spotify_session,
            'spotify_authorize_url' => $spotify_authorize_url,
            'spotify_parser_in_q' => $spotify_parser_in_q,
        ));
    }

    /**
     * Search for artist
     *
     * @param Request $request
     */
    public function searchAction(Request $request)
    {
        $q = $request->query->get('query');

        CallerFactory::getDefaultCaller()->setApiKey($this->container->getParameter('kraken.lastfm.api_key'));

        $correction = $this->__getCorrection($q);
        if ($correction) {
            $q = $correction->getName();
        }

        $results = Artist::search($q, 10);
        $json_prepare = array();
        if ($results) {
            while ($artist = $results->current()) {
                $json_prepare[] = array(
                    'name' => $artist->getName()
                );
                $artist = $results->next();
            }
            $response = new Response(json_encode($json_prepare));
            $response->headers->set('Content-Type', 'application/json');
            return $response;
        } else {
            throw $this->createNotFoundException();
        }
    }

    /**
     * Save artist
     *
     * @param Request $request
     */
    public function saveAction(Request $request)
    {
        $user = $this->__getUser();
        if (!$user) { //no user authenticated? redirect to the login page
            return $this->redirect($this->generateUrl('krakenfm_login'));
        }
        $name = $request->query->get('name');
        $_lastfm = new Lastfm($this->getDoctrine(), $this->container);
        if (!$name) {
            throw $this->createNotFoundException();
        }
        $tag_compiles = $_lastfm->getCompilesTags($name);
        $artist = $_lastfm->addOrCreateArtist($name, $tag_compiles, $user);
        $response = new Response(json_encode(array()));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    /**
     * Save artist
     *
     * @param Request $request
     */
    public function removeAction(Request $request)
    {
        $user = $this->__getUser();
        if (!$user) { //no user authenticated? redirect to the login page
            return $this->redirect($this->generateUrl('krakenfm_login'));
        }
        $name = $request->query->get('name');
        CallerFactory::getDefaultCaller()->setApiKey($this->container->getParameter('kraken.lastfm.api_key'));
        if (!$name) {
            throw $this->createNotFoundException();
        }
        $this->__removeArtist($name, $user);
        $tracks = $this->__getTracks($user);
        $tracks_count = count($tracks);
        $response = new Response(json_encode(array('tracks_count' => $tracks_count)));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    /**
     * Tracks
     *
     * @param Request $request
     */
    public function tracksAction(Request $request)
    {
        $user = $this->__getUser();
        $_lastfm = new Lastfm($this->getDoctrine(), $this->container);
        if (!$user) { //no user authenticated? redirect to the login page
            return $this->redirect($this->generateUrl('krakenfm_login'));
        }
        $name = $request->query->get('name');

        CallerFactory::getDefaultCaller()->setApiKey($this->container->getParameter('kraken.lastfm.api_key'));
        try {
            $tracks = Artist::getTopTracks($name);
        } catch (\Exception $e) {
            $tracks = array();
        }

        $custom_tracks = $this->__getCustomTracks($name, $user);

        $fav_tracks = $_lastfm->getTracksForArtist($name, $user);
        $fav_track_names = array();
        foreach ($fav_tracks as $fav_track) {
            $fav_track_names[$fav_track->getTrack()] = $fav_track->getTrack();
        }

        return $this->render('KrakenfmBundle:Default:tracks.html.twig', array(
            'tracks' => array_slice($tracks, 0, 10),
            'custom_tracks' => $custom_tracks,
            'artist_name' => $name,
            'fav_track_names' => $fav_track_names,
        ));
    }

    /**
     * @param Request $request
     */
    public function toggleTrackAction(Request $request)
    {
        $artist_name = $request->query->get('artist');
        $track_name = $request->query->get('track');

        if (!$artist_name || !$track_name) {
            throw $this->createNotFoundException();
        }

        $user = $this->__getUser();
        if (!$user) { //no user authenticated? redirect to the login page
            return $this->redirect($this->generateUrl('krakenfm_login'));
        }
        $_lastfm = new Lastfm($this->getDoctrine(), $this->container);
        $track = $_lastfm->getTrack($artist_name, $track_name, $user);
        if ($track) { //track found - delete it
            $em = $this->getDoctrine()->getManager();
            $em->remove($track);
            $em->flush();
            $response = new Response(json_encode(array('active' => false)));
            $response->headers->set('Content-Type', 'application/json');
            return $response;
        } else { //track not found - trying to add new one
            $spotify_api = new SpotifyWebApiExtended();
            $search_string = 'track:"'.$track_name.'" artist:"'.$artist_name.'"';
            $find_track = $spotify_api->search($search_string, 'track');
            $is_explicit = false;
            foreach ($find_track->tracks->items as $item) {
                if ($item->name == $track_name) {
                    $is_explicit = $item->explicit;
                }
            }

            $result = $_lastfm->addTrack($artist_name, $track_name, $user, false, $is_explicit);
            $response = new Response(json_encode(array('active' => $result)));
            $response->headers->set('Content-Type', 'application/json');
            return $response;
        }
    }

    /**
     * Save custom track
     *
     * @param Request $request
     */
    public function saveCustomTrackAction(Request $request)
    {
        $user = $this->__getUser();
        $_lastfm = new Lastfm($this->getDoctrine(), $this->container);
        if (!$user) { //no user authenticated? redirect to the login page
            return $this->redirect($this->generateUrl('krakenfm_login'));
        }

        $artist_name = $request->query->get('artist');
        $track_name = $request->query->get('track');
        $order = $request->query->get('order');

        if (!$artist_name || !$track_name || !$order) {
            $this->createNotFoundException();
        }

        $_lastfm->createOrEditCustomTrack($artist_name, $track_name, $order, $user);
        $response = new Response(json_encode(array()));
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    /**
     * Get an excel file
     *
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function csvAction()
    {
        $user = $this->__getUser();
        if (!$user) { //no user authenticated? redirect to the login page
            return $this->redirect($this->generateUrl('krakenfm_login'));
        }

        $tracks = $this->__getTracks($user);
        $artists = $this->__getArtists($user);
        $tags = array();
        $is_spotify_artists = array();
        foreach ($artists as $artist) {
            $tags[$artist->getName()] = $artist->getTags();
            $is_spotify_artists[$artist->getName()] = $artist->getIsSpotifyArtist();
        }

        $phpExcelObject = $this->get('phpexcel')->createPHPExcelObject();

        $phpExcelObject->setActiveSheetIndex(0)
            ->setCellValue('A1', 'Song')
            ->setCellValue('B1', 'Artist')
            ->setCellValue('C1', 'Tags')
            ->setCellValue('D1', 'Album')
            ->setCellValue('E1', 'Year')
            ->setCellValue('F1', 'Top 10')
            ->setCellValue('G1', 'Spotify Song')
            ->setCellValue('H1', 'Spotify Artist')
            ->setCellValue('I1', 'Explicit');
        $_i = 2;
        foreach ($tracks as $track) {
            $date = $track->getYear();
            $date_explode = explode("-", $date);
            if (count($date_explode) == 3) {
                $year = $date_explode[0];
            } else {
                $year = $date;
            }
            $phpExcelObject->setActiveSheetIndex(0)
                ->setCellValue('A'.$_i, $track->getTrack())
                ->setCellValue('B'.$_i, $track->getArtist())
                ->setCellValue('C'.$_i, $tags[$track->getArtist()])
                ->setCellValue('D'.$_i, $track->getAlbum())
                ->setCellValue('E'.$_i, $year)
                ->setCellValue('F'.$_i, $track->getIsTop10() ? 'Yes' : 'No')
                ->setCellValue('G'.$_i, $track->getIsSpotifySong() ? 'Yes' : 'No')
                ->setCellValue('H'.$_i, $is_spotify_artists[$track->getArtist()] ? 'Yes' : 'No')
                ->setCellValue('I'.$_i, $track->getIsExplicit() ? 'Yes' : 'No');
            $_i++;
        }
        $phpExcelObject->setActiveSheetIndex(0);

        foreach (range('A', $phpExcelObject->getActiveSheet()->getHighestDataColumn()) as $col) {
            $phpExcelObject->getActiveSheet()
                ->getColumnDimension($col)
                ->setAutoSize(true);
        }

        $writer = $this->get('phpexcel')->createWriter($phpExcelObject, 'Excel5');
        $response = $this->get('phpexcel')->createStreamedResponse($writer);
        $response->headers->set('Content-Type', 'text/vnd.ms-excel; charset=utf-8');
        $response->headers->set('Content-Disposition', 'attachment;filename="'.$user->getEmail().' Music List.xls"');
        $response->headers->set('Pragma', 'public');
        $response->headers->set('Cache-Control', 'maxage=1');

        return $response;
    }

    /**
     * Check user exists in the database.
     * If not - create new user.
     * Add found user to the session
     */
    private function __checkUser($email)
    {
        $user = $this->getDoctrine()->getRepository('KrakenfmBundle:User')->findOneByEmail($email); //find user
        if (!$user) { //no use with this email - create one
            $user = new User();
            $user->setEmail($email);

            $em = $this->getDoctrine()->getManager();
            $em->persist($user);
            $em->flush();
            //it's a new user - so let's send admin an email
            $this->__notifyAdminNewUser($email);
        }
        //save user id to the session
        $session = $this->get('session');
        $session->set('user_id', $user->getId());
    }

    /**
     * Send email to admin about new user registered.
     *
     * @param $email
     */
    private function __notifyAdminNewUser($email)
    {
        $mailer = $this->get('mailer');
        $message = $mailer->createMessage()
            ->setSubject($this->container->getParameter('kraken.notify_new_user.subject'))
            ->setFrom($this->container->getParameter('kraken.notify_new_user.from'))
            ->setTo($this->container->getParameter('kraken.admin_email'))
            ->setBody(
                $this->renderView(
                    'KrakenfmBundle:Emails:registration.html.twig',
                    array('email' => $email)
                ),
                'text/html'
            );
        $mailer->send($message);
    }

    /**
     * Find user by ID saved in the session
     *
     * @return object
     */
    private function __getUser()
    {
        $user_id = $this->get('session')->get('user_id', 0);
        $user = $this->getDoctrine()->getRepository('KrakenfmBundle:User')->find($user_id);
        return $user;
    }

    /**
     * @param $name
     * @param $user
     */
    private function __removeArtist($name, $user)
    {
        $em = $this->getDoctrine()->getManager();
        $artist = $this->getDoctrine()->getRepository('KrakenfmBundle:Artist')->findOneBy(
            array('name' => $name, 'user_id' => $user->getId())
        );
        $tracks = $this->__getTracksForArtist($artist->getName(), $user);
        foreach ($tracks as $track) {
            $em->remove($track);
        }
        if ($artist) {
            $em->remove($artist);
            $em->flush();
        }
    }

    /**
     * Get Artists for the user
     *
     * @param $user
     * @return array
     */
    private function __getArtists($user)
    {
        $artists = $this->getDoctrine()->getRepository('KrakenfmBundle:Artist')->findBy(
            array('user_id' => $user->getId())
        );
        return $artists;
    }

    /**
     * Find all tracks for the user.
     *
     * @param $artist
     * @param $track
     * @param $user
     */
    private function __getTracks($user)
    {
        $tracks = $this->getDoctrine()->getRepository('KrakenfmBundle:Track')->findBy(
            array('user_id' => $user->getId()),
            array('artist' => 'ASC', 'track' => 'ASC')
        );
        return $tracks;
    }

    /**
     * @param $artist
     * @return array
     */
    private function __getCorrection($artist)
    {
        try {
            $xml = CallerFactory::getDefaultCaller()->call('artist.getCorrection', array(
                'artist' => $artist,
            ));
        } catch (\Exception $e) {
            return false;
        }
        if (!$xml) {
            return false;
        }
        if ($xml->correction->artist) {
            return Artist::fromSimpleXMLElement($xml->correction->artist);
        } else {
            return false;
        }
    }

    /**
     * Get custom tracks for artist
     *
     * @param $artist
     * @param $user
     */
    private function __getCustomTracks($artist, $user)
    {
        $result = $this->getDoctrine()->getRepository('KrakenfmBundle:CustomTrack')->findBy(
            array('artist' => $artist, 'user_id' => $user->getId()), array(), 3
        );
        $empty_tracks_count = 3 - count($result);
        for ($i = 0; $i < $empty_tracks_count; $i++) {
            $result[] = new CustomTrack();
        }
        return $result;
    }
}