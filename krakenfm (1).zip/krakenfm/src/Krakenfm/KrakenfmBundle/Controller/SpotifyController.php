<?php

namespace Krakenfm\KrakenfmBundle\Controller;

use Krakenfm\KrakenfmBundle\Basic\Lastfm;
use Krakenfm\KrakenfmBundle\Basic\Spotify;
use MyProject\Proxies\__CG__\stdClass;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use LastFM\Artist;
use LastFM\Caller\CallerFactory;

class SpotifyController extends Controller
{
    public function authAction(Request $request)
    {
        $user = $this->__getUser();
        if (!$user) {
            $this->redirect($this->generateUrl('krakenfm_login'));
        }

        $spotify_params = array();
        $spotify_params['client_id'] = $this->container->getParameter('kraken.spotify.client_id');
        $spotify_params['client_secrete'] = $this->container->getParameter('kraken.spotify.client_secret');
        $spotify_params['scopes'] = $this->container->getParameter('kraken.spotify.scopes');
        $spotify_params['redirect_uri'] = $this->generateUrl('spotify_auth', array(), UrlGeneratorInterface::ABSOLUTE_URL);

        $spotify_session = new \SpotifyWebAPI\Session($spotify_params['client_id'],
                                                      $spotify_params['client_secrete'],
                                                      $spotify_params['redirect_uri']);

        $code = $request->query->get('code');
        $spotify_session->requestAccessToken($code);
        $access_token = $spotify_session->getAccessToken();

        $user->setSpotifyAccessToken($access_token);
        $user->setRunSpotify(true);
        $this->_saveUser($user);

        //$this->_runParser($user);

        return $this->redirect($this->generateUrl('krakenfm_dashboard').'?spotify=1');

    }

    public function checkAction(Request $request)
    {
        $user = $this->__getUser();
        if (!$user) {
            $this->redirect($this->generateUrl('krakenfm_login'));
        }

        $previous_spotify_parser = $this->getDoctrine()->getRepository('KrakenfmBundle:SpotifyParser')
            ->findOneBy(array(
                'user' => $user,
                'isRunning' => 1,
            ));

        $response = new JsonResponse();
        if ($previous_spotify_parser || $user->getRunSpotify()) {
            $data = array('is_finished' => false);
        } else {
            $data = array('is_finished' => true);
        }

        /*
        $artists = $this->__getArtists($user);
        $artist_list = $this->render('KrakenfmBundle::Default/partials/_artist_list.html.twig',
            array('artists' => $artists)
        );

        $data['artist_list'] = $artist_list->getContent();
        */

        $response->setData($data);

        return $response;
    }

    /**
     * Find user by ID saved in the session
     *
     * @return object
     */
    private function __getUser()
    {
        $user_id = $this->get('session')->get('user_id', 0);
        $user = $this->getDoctrine()->getRepository('KrakenfmBundle:User')->find($user_id);
        return $user;
    }

    private function _saveUser($user)
    {
        $em = $this->getDoctrine()->getManager();
        $em->persist($user);
        $em->flush();
    }

    private function _runParser($user)
    {
        $path = $this->get('kernel')->getRootDir();
        $command = "php ".$path."/console krakenfm:spotify_parser ".$user->getId()." > /dev/null 2>/dev/null &";
        exec($command);
    }

    /**
     * Get Artists for the user
     *
     * @param $user
     * @return array
     */
    private function __getArtists($user)
    {
        $artists = $this->getDoctrine()->getRepository('KrakenfmBundle:Artist')->findBy(
            array('user_id' => $user->getId())
        );
        return $artists;
    }
}