var save_artist_url;
var remove_artist_url;
var artist_list = [];
var show_tracks_url;
var toggle_track_url;
var save_custom_track_url;

function clearSearchField() {
    $('#artist_search_field').val('');
}

function addCustomArtist() {
    var artist_name = $('#artist_search_field').val();
    addArtist(artist_name);
}

function addArtist(artist_name) {
    if (artist_list.indexOf(artist_name) >= 0) {
        return;
    }
    $('#ArtistList').append('<li class="list-group-item" artist_name="'+encodeURIComponentExt(artist_name)+'"><a href="javascript: showTracks(\''+addslashes(artist_name)+'\');">'+escapeHTML(artist_name)+'</a><a href="javascript: removeArtist(\''+addslashes(artist_name)+'\');" style="float: right;"><i class="glyphicon glyphicon-remove"></i></a></li>');
    updateArtistSort();
    increaseArtistCount();
    saveArtist(artist_name);
    artist_list.push(artist_name);
    clearSearchField();
    $('#SearchAjaxLoader').hide();
}

function increaseArtistCount() {
    var _count = parseInt($('#ArtistCount').text());
    _count++;
    $('#ArtistCount').html(_count);
}

function decreaseArtistCount() {
    var _count = parseInt($('#ArtistCount').text());
    _count--;
    $('#ArtistCount').html(_count);
}

function increaseTrackCount() {
    var _count = parseInt($('#TrackCount').text());
    _count++;
    $('#TrackCount').html(_count);
}

function decreaseTrackCount() {
    var _count = parseInt($('#TrackCount').text());
    _count--;
    $('#TrackCount').html(_count);
}

function saveArtist(artist_name) {
    $.get(save_artist_url, { "name": artist_name });
}

function removeArtist(artist_name) {
    $.get(remove_artist_url, { "name": artist_name }, function(data) {
        $('#TrackCount').html(data.tracks_count);
    });
    $('#ArtistList').find('li[artist_name="'+encodeURIComponentExt(artist_name)+'"]').remove();
    var _mb_index = artist_list.indexOf(artist_name);
    if (_mb_index >= 0) {
        artist_list.splice(_mb_index, 1);
    }
    decreaseArtistCount();
    $('#TrackList').html('');
}

function updateArtistSort() {
    var _container = $("#ArtistList");
    var _list = $( "li", "#ArtistList" );
    _list.sort(function( a, b ) {
        var _a = $(a).text().trim().toLowerCase();
        var _b = $(b).text().trim().toLowerCase();
        return _a > _b ? 1 : -1;
    });
    $.each(_list, function (index, row) {
        _container.append(row);
    });
};

function showTracks(artist_name) {
    $('#ArtistList').find('li').removeClass('active');
    var artist_container = $('#ArtistList').find('li[artist_name="'+encodeURIComponentExt(artist_name)+'"]');
    artist_container.addClass('active');
    $.get(show_tracks_url, { 'name': artist_name}, function(html) {
        $('#TrackList').html(html);
        var _top = artist_container.position().top - $('#TrackList').height() / 2;
        if (_top <= 0) {
            _top = 0;
        }
        $('#TrackList').css('top', _top);
    });
}

function toggleTrack(artist_name, track_name) {
    $.get(toggle_track_url, { 'artist': artist_name, 'track': track_name }, function (data) {
        if (data.active) {
            $('#TrackList').find('li[track_name="' + encodeURIComponentExt(track_name) + '"]').addClass('active');
            increaseTrackCount();
        } else {
            $('#TrackList').find('li[track_name="' + encodeURIComponentExt(track_name) + '"]').removeClass('active');
            decreaseTrackCount();
        }
    });
}

function saveCustomTrack(artist, order) {
    var track = $('#TrackList').find('li[order_id='+order+']').find('input[name=track_name]').val().trim();
    if (!track) {
        return;
    }
    $.get(save_custom_track_url, {'artist': artist, 'track': track, 'order': order}, function (data) {
        uneditCustomTrack(artist, order);
        updateCustomTrack(artist, track, order);
    });
}

function updateCustomTrack(artist, track, order) {
    $('#TrackList').find('li[order_id='+order+']').attr('track_name', encodeURIComponentExt(track));
    var new_html = '<a href=\'javascript: toggleTrack("'+addslashes(artist)+'", "'+addslashes(track)+'");\'>'+escapeHTML(track)+'</a>';
    $('#TrackList').find('span.show_custom_track[order_id='+order+']').find('span.show_custom_track_url').html(new_html);
}

function uneditCustomTrack(artist, order) {
    $('#TrackList').find('span.edit_custom_track[order_id='+order+']').hide();
    $('#TrackList').find('span.show_custom_track[order_id='+order+']').show();
}

function editCustomTrack(artist, order) {
    $('#TrackList').find('span.edit_custom_track[order_id='+order+']').show();
    $('#TrackList').find('span.show_custom_track[order_id='+order+']').hide();
}

function escapeHTML(text) {
    return text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function addslashes(str) {
    return (str + '')
        .replace(/[\\"']/g, '\\$&')
        .replace(/\u0000/g, '\\0');
}

function encodeURIComponentExt(str) {
    return encodeURIComponent(str).replace(/'/g, "%27").replace(/!/g, "%21").replace(/\*/g, "%2A").replace(/\(/g, "%28").replace(/\)/g, "%29");
}