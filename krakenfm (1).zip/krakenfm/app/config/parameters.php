<?php
$container->setParameter('database_driver', 'pdo_mysql');
if(@$_SERVER['RDS_HOSTNAME']) {
    $container->setParameter('database_host', $_SERVER['RDS_HOSTNAME']);
    $container->setParameter('database_port', $_SERVER['RDS_PORT']);
    $container->setParameter('database_name', $_SERVER['RDS_DB_NAME']);
    $container->setParameter('database_user', $_SERVER['RDS_USERNAME']);
    $container->setParameter('database_password', $_SERVER['RDS_PASSWORD']);
} else {
    $container->setParameter('database_host', '127.0.0.1');
    $container->setParameter('database_port', null);
    $container->setParameter('database_name', 'krakenfm');
    $container->setParameter('database_user', 'krakenfm');
    $container->setParameter('database_password', 'krakenfm');
}
$container->setParameter('mailer_transport', 'smtp');
$container->setParameter('mailer_host', '127.0.0.1');
$container->setParameter('mailer_user', null);
$container->setParameter('mailer_password', null);
$container->setParameter('locale', 'en');
$container->setParameter('secret', '09ea881116d800695eb6dfcf7415939dceb85a2d');

$container->setParameter('kraken.admin_email', 'jono@trackn.fm');
$container->setParameter('kraken.notify_new_user.subject', 'A new user has registered');
$container->setParameter('kraken.notify_new_user.from', 'noreply@krakenfm.elasticbeanstalk.com');
$container->setParameter('kraken.lastfm.api_key', 'cf75c779346c1e0c401e68d4dd55db8a');
$container->setParameter('kraken.lastfm.secret', '1e7285aadc701bad674172a1e7eeb0a2');

$container->setParameter('kraken.spotify.client_id', 'd867239cb4724c59821e9ad69b25ddc2');
$container->setParameter('kraken.spotify.client_secret', '7950bf1634fb4faba5898778cfdce30e');
$container->setParameter('kraken.spotify.scopes', array('user-library-read', 'user-read-private', 'user-follow-read', 'playlist-read-private', 'playlist-read-collaborative'));