<?php

use Doctrine\Common\Annotations\AnnotationRegistry;
use Composer\Autoload\ClassLoader;

/**
 * @var ClassLoader $loader
 */
$loader = require __DIR__.'/../vendor/autoload.php';

AnnotationRegistry::registerLoader(array($loader, 'loadClass'));

$loader->add('LastFM', __DIR__.'/../lastfm/src');
$loader->add('SpotifyWebAPI', __DIR__.'/../vendor/jwilsson/spotify-web-api-php/src');

return $loader;
