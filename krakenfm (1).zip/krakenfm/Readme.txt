How to install
==============

1. Extract archive to your server.
2. Use dump.sql and create structure for MySQL with it.
3. Edit app/config/parameters.php:
3.1. Set mysql options with database_* parameters
3.2. Set kraken.admin_email - email about new users will be sent to this address
3.3. Set kraken.notify_new_user.subject - this is a subject of email sent to admin
3.4. Set kraken.notify_new_user.from: - emails to admin will be sent from this address
3.5. Set both kraken.lastfm.api_key and kraken.lastfm.secret. 
To get both "Api Key" and "Secret" please create an account here: http://www.lastfm.ru/api/account/create

How it works
============
You can find all essential code inside Krakenfm/KrakenfmBundle
The main controller is Krakenfm/KrakenfmBundle/Controller/DefaultController.php
All templates can be found at: Krakenfm/KrakenfmBundle/Resources/views/*
Main Javascript: web/js/main.js
Main CSS: web/css/main.css

1. Login page
Uri: "/"
Controller action method: "loginAction"
Template: Krakenfm/KrakenfmBundle/Resources/views/Default/login.html.twig
Email template: Krakenfm/KrakenfmBundle/Resources/views/Emails/registration.html.twig
Description: 
User enters email. Script checks if it's correct email. 
If email exists - we redirect user to the dashboard.
If email doesn't exist - we create a new user inside database, 
send email to the admin (__notifyAdminNewUser method) and redirect user to the dashboard.

2. Dashboard page
Uri: "/dashboard"
Controller action method: "dashboardAction"
Template: Krakenfm/KrakenfmBundle/Resources/views/Default/dashboard.html.twig
Description:
Page shows search form, added artists, artists and tracks count, etc

3. Search
Uri: "/search"
Controller action method: "searchAction"
Template: returns search results as JSON
Description:
Action uses LastFM API to search for artists.
First, it tries to get correct name for artist. If correction is found - it is used to
search using API. If correction is not found - search query used as is.
Script gets 10 top search results and returns them as JSON.
Search results are displayed as autocomplete block.

4. Save artist
Uri: "/save"
Controller action method: "saveAction"
Description:
Saves artist to the database for currect user. Artist is saved with top 10 tags got from LastFM API

5. Remove artist
Uri: "/remove"
Controller action method: "removeAction"
Description:
Removes artist from the database for currect user.

6. Track list
Uri: "/tracks"
Controller action method: "tracksAction"
Template: Krakenfm/KrakenfmBundle/Resources/views/Default/tracks.html.twig
Description:
Shows 10 top tracks for the specified artist and 3 custom tracks added by user.
It also shows if tracks are selected or not.

7. Toggle Track
Uri: "/toggle_track"
Controller action method: "toggleTrackAction"
Description:
Toggles tracks status: selected or not.
If track was selected - deselects it.
If track wasn't selected - checks if there are less than 3 tracks selected for this artist and selects 
track if not.

8. Export to XLS
Uri: "/csv"
Controller action method: "csvAction"
Description:
Gets all data saved for current user and exports it as an XLS file.

9. Save custom track
Uri: "/save_custom_track"
Controller action method: "saveCustomTrackAction"
Description:
Saved or edits custom track name.