<?php

namespace LastFM;

/** An error exception.
 *
 * @package	php-lastfm-api
 * @author  Felix Bruns <felixbruns@web.de>
 * @version	1.0
 */
class Error extends \Exception { }


